import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Users, Scale, DollarSign, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';
import { motion } from 'motion/react';

export default function Layout({ children }: { children: React.ReactNode }) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  return (
    <div className="flex h-screen bg-gray-50 text-gray-900 font-sans">
      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 256 : 80 }}
        className="bg-slate-900 text-white flex-shrink-0 flex flex-col transition-all duration-300 shadow-xl z-20"
      >
        <div className="h-16 flex items-center justify-between px-4 border-b border-slate-800">
          {isSidebarOpen && <span className="font-bold text-xl tracking-tight">HR Nexus</span>}
          <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="p-2 hover:bg-slate-800 rounded-lg">
            {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>

        <nav className="flex-1 py-6 space-y-2 px-2">
          <NavItem to="/" icon={<LayoutDashboard size={20} />} label="Dashboard" isOpen={isSidebarOpen} />
          <NavItem to="/discounts" icon={<DollarSign size={20} />} label="Gestão de Descontos" isOpen={isSidebarOpen} />
          <NavItem to="/lawsuits" icon={<Scale size={20} />} label="Processos Trabalhistas" isOpen={isSidebarOpen} />
          <NavItem to="/hiring" icon={<Users size={20} />} label="Recrutamento" isOpen={isSidebarOpen} />
        </nav>

        <div className="p-4 border-t border-slate-800">
          {isSidebarOpen && (
            <div className="text-xs text-slate-400">
              <p>HR System v1.0</p>
              <p>Logged in as Admin</p>
            </div>
          )}
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto relative">
        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-8 sticky top-0 z-10">
          <h1 className="text-xl font-semibold text-gray-800">Portal de Recursos Humanos</h1>
          <div className="flex items-center gap-4">
            <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold">
              RH
            </div>
          </div>
        </header>
        <div className="p-8 max-w-7xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
}

function NavItem({ to, icon, label, isOpen }: { to: string; icon: React.ReactNode; label: string; isOpen: boolean }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        cn(
          "flex items-center gap-3 px-3 py-3 rounded-lg transition-colors",
          isActive ? "bg-indigo-600 text-white shadow-md" : "text-slate-300 hover:bg-slate-800 hover:text-white"
        )
      }
    >
      <div className="flex-shrink-0">{icon}</div>
      {isOpen && <span className="whitespace-nowrap font-medium">{label}</span>}
    </NavLink>
  );
}

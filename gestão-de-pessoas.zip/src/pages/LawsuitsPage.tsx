import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Plus, Gavel, Calendar, AlertTriangle, FileText, DollarSign, MapPin, Scale, Clock, ChevronDown, ChevronUp } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

type Lawsuit = {
  id: number;
  // Identificação
  case_number: string;
  claimant_name: string;
  respondent_name: string;
  labor_court: string;
  tribunal: string;
  // Cronograma
  distribution_date: string;
  initial_hearing_date: string;
  instruction_hearing_date: string;
  defense_deadline: string;
  reply_deadline: string;
  expert_analysis_date: string;
  sentence_publication_date: string;
  appeal_deadline: string;
  // Conteúdo
  main_claims: string;
  admission_date: string;
  termination_date: string;
  last_salary: number;
  // Financeiro
  cause_value: number;
  condemnation_value: number;
  appeal_deposit: number;
  risk_provision: 'Probable' | 'Possible' | 'Remote';
  court_costs: number;
  // Status
  current_phase: string;
  last_progress: string;
  next_action: string;
};

export default function LawsuitsPage() {
  const [lawsuits, setLawsuits] = useState<Lawsuit[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedLawsuit, setSelectedLawsuit] = useState<Lawsuit | null>(null);

  useEffect(() => {
    fetchLawsuits();
  }, []);

  const fetchLawsuits = async () => {
    const res = await fetch('/api/lawsuits');
    const data = await res.json();
    setLawsuits(data);
  };

  const handleEdit = (lawsuit: Lawsuit) => {
    setSelectedLawsuit(lawsuit);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedLawsuit(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Processos Trabalhistas</h2>
          <p className="text-gray-500">Gestão completa de contencioso trabalhista.</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 font-medium shadow-sm"
        >
          <Plus size={18} /> Novo Processo
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {lawsuits.map((lawsuit) => (
          <LawsuitCard key={lawsuit.id} lawsuit={lawsuit} onEdit={() => handleEdit(lawsuit)} />
        ))}
        {lawsuits.length === 0 && (
          <div className="text-center py-12 bg-white rounded-xl border border-dashed border-gray-300">
            <Gavel className="mx-auto h-12 w-12 text-gray-300 mb-3" />
            <p className="text-gray-500">Nenhum processo cadastrado.</p>
          </div>
        )}
      </div>

      <NewLawsuitModal 
        isOpen={isModalOpen} 
        onClose={handleCloseModal} 
        onCreated={fetchLawsuits} 
        initialData={selectedLawsuit}
      />
    </div>
  );
}

function LawsuitCard({ lawsuit, onEdit }: { lawsuit: Lawsuit; onEdit: () => void }) {
  const [expanded, setExpanded] = useState(false);
  
  // Determine urgency based on next immediate deadline (simplified logic)
  const deadlines = [
    lawsuit.initial_hearing_date,
    lawsuit.instruction_hearing_date,
    lawsuit.defense_deadline,
    lawsuit.reply_deadline,
    lawsuit.appeal_deadline
  ].filter(Boolean).map(d => new Date(d));
  
  const nextDeadline = deadlines.sort((a, b) => a.getTime() - b.getTime()).find(d => d > new Date());
  const isUrgent = nextDeadline && nextDeadline < new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }} 
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden group"
    >
      <div className="p-6 cursor-pointer hover:bg-gray-50 transition-colors relative" onClick={() => setExpanded(!expanded)}>
        <button 
          onClick={(e) => { e.stopPropagation(); onEdit(); }}
          className="absolute top-6 right-12 p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-full transition-colors z-10"
          title="Editar Processo"
        >
          <Edit2 size={18} />
        </button>

        <div className="flex justify-between items-start">
          <div className="flex gap-4 items-start">
            <div className="bg-red-50 p-3 rounded-lg text-red-600">
              <Scale size={24} />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-mono bg-gray-100 text-gray-600 px-2 py-0.5 rounded border border-gray-200">
                  {lawsuit.case_number}
                </span>
                <span className={cn("px-2 py-0.5 rounded-full text-xs font-medium border", 
                  lawsuit.risk_provision === 'Probable' ? "bg-red-50 text-red-700 border-red-100" :
                  lawsuit.risk_provision === 'Possible' ? "bg-yellow-50 text-yellow-700 border-yellow-100" :
                  "bg-green-50 text-green-700 border-green-100"
                )}>
                  Risco: {lawsuit.risk_provision === 'Probable' ? 'Provável' : lawsuit.risk_provision === 'Possible' ? 'Possível' : 'Remoto'}
                </span>
              </div>
              <h3 className="text-lg font-bold text-gray-900">{lawsuit.claimant_name}</h3>
              <p className="text-sm text-gray-500 flex items-center gap-1 mt-1">
                <MapPin size={14} /> {lawsuit.labor_court} - {lawsuit.tribunal}
              </p>
            </div>
          </div>
          
          <div className="text-right">
            <div className="text-sm font-medium text-gray-900 mb-1">Fase: {lawsuit.current_phase}</div>
            {nextDeadline && (
              <div className={cn("flex items-center gap-1 text-sm", isUrgent ? "text-red-600 font-bold" : "text-gray-500")}>
                <Calendar size={14} />
                {format(nextDeadline, "dd/MM/yyyy")}
              </div>
            )}
            <div className="mt-2 text-gray-400">
              {expanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
            </div>
          </div>
        </div>
      </div>

      {expanded && (
        <div className="border-t border-gray-100 bg-gray-50/50 p-6 grid grid-cols-1 md:grid-cols-3 gap-8 text-sm">
          {/* Coluna 1: Detalhes e Datas */}
          <div className="space-y-4">
            <h4 className="font-semibold text-gray-900 flex items-center gap-2">
              <Calendar size={16} className="text-gray-500" /> Cronograma
            </h4>
            <div className="space-y-2 text-gray-600">
              <DateRow label="Distribuição" date={lawsuit.distribution_date} />
              <DateRow label="Audiência Inicial" date={lawsuit.initial_hearing_date} />
              <DateRow label="Audiência Instrução" date={lawsuit.instruction_hearing_date} />
              <DateRow label="Prazo Defesa" date={lawsuit.defense_deadline} highlight />
              <DateRow label="Prazo Réplica" date={lawsuit.reply_deadline} />
              <DateRow label="Perícia" date={lawsuit.expert_analysis_date} />
              <DateRow label="Sentença" date={lawsuit.sentence_publication_date} />
              <DateRow label="Prazo Recursal" date={lawsuit.appeal_deadline} highlight />
            </div>
          </div>

          {/* Coluna 2: Objeto e Financeiro */}
          <div className="space-y-4">
            <h4 className="font-semibold text-gray-900 flex items-center gap-2">
              <FileText size={16} className="text-gray-500" /> Objeto & Financeiro
            </h4>
            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <InfoBlock label="Admissão" value={formatDate(lawsuit.admission_date)} />
                <InfoBlock label="Demissão" value={formatDate(lawsuit.termination_date)} />
              </div>
              <InfoBlock label="Último Salário" value={formatCurrency(lawsuit.last_salary)} />
              <div className="h-px bg-gray-200 my-2" />
              <InfoBlock label="Valor da Causa" value={formatCurrency(lawsuit.cause_value)} />
              <InfoBlock label="Condenação" value={formatCurrency(lawsuit.condemnation_value)} highlight />
              <InfoBlock label="Depósito Recursal" value={formatCurrency(lawsuit.appeal_deposit)} />
              <InfoBlock label="Custas" value={formatCurrency(lawsuit.court_costs)} />
            </div>
            <div className="mt-4">
               <p className="text-xs font-medium text-gray-500 uppercase mb-1">Pedidos Principais</p>
               <p className="text-gray-700 bg-white p-2 rounded border border-gray-200">{lawsuit.main_claims}</p>
            </div>
          </div>

          {/* Coluna 3: Status e Andamento */}
          <div className="space-y-4">
            <h4 className="font-semibold text-gray-900 flex items-center gap-2">
              <Clock size={16} className="text-gray-500" /> Status & Próximos Passos
            </h4>
            <div className="bg-white p-3 rounded-lg border border-gray-200 space-y-3">
              <div>
                <p className="text-xs font-medium text-gray-500 uppercase">Último Andamento</p>
                <p className="text-gray-700 mt-1">{lawsuit.last_progress || 'Sem andamento registrado'}</p>
              </div>
              <div className="border-t border-gray-100 pt-3">
                <p className="text-xs font-medium text-gray-500 uppercase">Próxima Providência</p>
                <p className="text-indigo-700 font-medium mt-1">{lawsuit.next_action || 'Aguardando definição'}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
}

function DateRow({ label, date, highlight }: { label: string; date: string; highlight?: boolean }) {
  if (!date) return null;
  return (
    <div className="flex justify-between">
      <span>{label}:</span>
      <span className={cn("font-medium", highlight ? "text-red-600" : "text-gray-900")}>
        {format(new Date(date), "dd/MM/yyyy")}
      </span>
    </div>
  );
}

function InfoBlock({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-gray-600">{label}:</span>
      <span className={cn("font-medium", highlight ? "text-red-700" : "text-gray-900")}>{value}</span>
    </div>
  );
}

function formatDate(dateStr: string) {
  if (!dateStr) return '-';
  return format(new Date(dateStr), "dd/MM/yyyy");
}

function formatCurrency(val: number) {
  if (val === undefined || val === null) return '-';
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val);
}

function NewLawsuitModal({ isOpen, onClose, onCreated, initialData }: { isOpen: boolean; onClose: () => void; onCreated: () => void; initialData: Lawsuit | null }) {
  const [activeTab, setActiveTab] = useState('identificacao');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const data: any = {};
    formData.forEach((value, key) => {
      if (value) data[key] = value;
    });

    const url = initialData ? `/api/lawsuits/${initialData.id}` : '/api/lawsuits';
    const method = initialData ? 'PUT' : 'POST';

    await fetch(url, {
      method: method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    
    onCreated();
    onClose();
  };

  const tabs = [
    { id: 'identificacao', label: 'Identificação' },
    { id: 'conhecimento', label: '1. Conhecimento' },
    { id: 'recursal', label: '2. Recursal' },
    { id: 'execucao', label: '3. Execução' },
    { id: 'financeiro', label: 'Financeiro' },
  ];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 overflow-y-auto">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="bg-white rounded-xl shadow-xl max-w-4xl w-full p-6 my-8 flex flex-col max-h-[90vh]">
        <div className="flex justify-between items-center mb-6 border-b pb-4">
          <h3 className="text-xl font-bold text-gray-900">{initialData ? 'Editar Processo' : 'Novo Processo Trabalhista'}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <span className="sr-only">Fechar</span>
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto">
          {/* Tabs */}
          <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg mb-6 overflow-x-auto">
            {tabs.map(tab => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "px-4 py-2 rounded-md text-sm font-medium whitespace-nowrap transition-colors",
                  activeTab === tab.id ? "bg-white text-gray-900 shadow-sm" : "text-gray-500 hover:text-gray-700"
                )}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="space-y-6 px-1">
            {activeTab === 'identificacao' && (
              <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input label="Número do Processo (CNJ)" name="case_number" defaultValue={initialData?.case_number} placeholder="0000000-00.0000.5.00.0000" required />
                  <Input label="Reclamante (Trabalhador)" name="claimant_name" defaultValue={initialData?.claimant_name} required />
                  <Input label="Reclamada (Empresa)" name="respondent_name" defaultValue={initialData?.respondent_name} />
                  <Input label="Vara do Trabalho" name="labor_court" defaultValue={initialData?.labor_court} placeholder="Ex: 2ª VT de São Paulo" />
                  <Input label="Tribunal" name="tribunal" defaultValue={initialData?.tribunal} placeholder="Ex: TRT-2" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Input label="Admissão" name="admission_date" type="date" defaultValue={initialData?.admission_date} />
                  <Input label="Demissão" name="termination_date" type="date" defaultValue={initialData?.termination_date} />
                  <Input label="Último Salário (R$)" name="last_salary" type="number" step="0.01" defaultValue={initialData?.last_salary} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Principais Pedidos</label>
                  <textarea name="main_claims" defaultValue={initialData?.main_claims} rows={3} className="w-full px-3 py-2 border border-gray-300 rounded-lg" placeholder="Ex: Horas Extras, Verbas Rescisórias, Danos Morais..." />
                </div>
              </div>
            )}

            {activeTab === 'conhecimento' && (
              <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 mb-4">
                  <p className="text-sm text-blue-800">Fase onde se discute o direito. O juiz ouve as partes e analisa provas.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Input label="1. Petição Inicial (Distribuição)" name="distribution_date" type="date" defaultValue={initialData?.distribution_date} />
                  <Input label="2. Notificação (Citação)" name="citation_date" type="date" defaultValue={initialData?.citation_date} />
                  <Input label="3. Audiência Inicial/Una" name="initial_hearing_date" type="date" defaultValue={initialData?.initial_hearing_date} />
                  <Input label="4. Prazo Defesa (Contestação)" name="defense_deadline" type="date" defaultValue={initialData?.defense_deadline} />
                  <Input label="5. Prazo Réplica" name="reply_deadline" type="date" defaultValue={initialData?.reply_deadline} />
                  <Input label="6. Data Perícia" name="expert_analysis_date" type="date" defaultValue={initialData?.expert_analysis_date} />
                  <Input label="7. Audiência Instrução" name="instruction_hearing_date" type="date" defaultValue={initialData?.instruction_hearing_date} />
                  <Input label="8. Razões Finais" name="final_arguments_date" type="date" defaultValue={initialData?.final_arguments_date} />
                  <Input label="9. Sentença (Publicação)" name="sentence_publication_date" type="date" defaultValue={initialData?.sentence_publication_date} />
                  <div>
                     <label className="block text-sm font-medium text-gray-700 mb-1">Resultado Sentença</label>
                     <select name="sentence_result" defaultValue={initialData?.sentence_result} className="w-full px-3 py-2 border border-gray-300 rounded-lg">
                       <option value="">Selecione...</option>
                       <option value="Procedente">Procedente</option>
                       <option value="Parcialmente Procedente">Parcialmente Procedente</option>
                       <option value="Improcedente">Improcedente</option>
                     </select>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'recursal' && (
              <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="bg-purple-50 p-4 rounded-lg border border-purple-100 mb-4">
                  <p className="text-sm text-purple-800">Revisão da decisão por instâncias superiores (TRT/TST).</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Input label="Prazo Recursal (Geral)" name="appeal_deadline" type="date" defaultValue={initialData?.appeal_deadline} />
                  <Input label="Interposição Recurso Ordinário" name="ro_filing_date" type="date" defaultValue={initialData?.ro_filing_date} />
                  <Input label="Interposição Recurso de Revista" name="rr_filing_date" type="date" defaultValue={initialData?.rr_filing_date} />
                </div>
              </div>
            )}

            {activeTab === 'execucao' && (
              <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="bg-green-50 p-4 rounded-lg border border-green-100 mb-4">
                  <p className="text-sm text-green-800">Cumprimento da decisão e pagamentos.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Input label="1. Liquidação de Sentença" name="liquidation_date" type="date" defaultValue={initialData?.liquidation_date} />
                  <Input label="2. Citação para Pagamento" name="payment_citation_date" type="date" defaultValue={initialData?.payment_citation_date} />
                  <Input label="3. Atos de Penhora" name="asset_seizure_date" type="date" defaultValue={initialData?.asset_seizure_date} />
                  <Input label="4. Pagamento Realizado" name="payment_date" type="date" defaultValue={initialData?.payment_date} />
                  <Input label="5. Arquivamento" name="archived_date" type="date" defaultValue={initialData?.archived_date} />
                </div>
              </div>
            )}

            {activeTab === 'financeiro' && (
              <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input label="Valor da Causa (R$)" name="cause_value" type="number" step="0.01" defaultValue={initialData?.cause_value} />
                  <Input label="Valor Condenação (R$)" name="condemnation_value" type="number" step="0.01" defaultValue={initialData?.condemnation_value} />
                  <Input label="Depósito Recursal (R$)" name="appeal_deposit" type="number" step="0.01" defaultValue={initialData?.appeal_deposit} />
                  <Input label="Custas e Honorários (R$)" name="court_costs" type="number" step="0.01" defaultValue={initialData?.court_costs} />
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Provisão de Risco</label>
                    <select name="risk_provision" defaultValue={initialData?.risk_provision} className="w-full px-3 py-2 border border-gray-300 rounded-lg">
                      <option value="Remote">Remota</option>
                      <option value="Possible">Possível</option>
                      <option value="Probable">Provável</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Fase Atual</label>
                    <select name="current_phase" defaultValue={initialData?.current_phase} className="w-full px-3 py-2 border border-gray-300 rounded-lg">
                      <option value="Conhecimento">Conhecimento</option>
                      <option value="Recurso">Recurso</option>
                      <option value="Execução">Execução</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <Input label="Próxima Providência" name="next_action" defaultValue={initialData?.next_action} placeholder="Ex: Aguardar publicação de sentença..." />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Último Andamento</label>
                    <textarea name="last_progress" defaultValue={initialData?.last_progress} rows={2} className="w-full px-3 py-2 border border-gray-300 rounded-lg" />
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-6 mt-6 border-t">
            <button type="button" onClick={onClose} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancelar</button>
            <button type="submit" className="px-4 py-2 bg-red-600 text-white hover:bg-red-700 rounded-lg font-medium">Salvar Processo</button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-gray-50 p-4 rounded-lg border border-gray-100">
      <h4 className="font-semibold text-gray-800 mb-3 text-sm uppercase tracking-wide">{title}</h4>
      {children}
    </div>
  );
}

function Input({ label, name, type = "text", placeholder, required, defaultValue }: { label: string; name: string; type?: string; placeholder?: string; required?: boolean; defaultValue?: any }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <input name={name} type={type} required={required} defaultValue={defaultValue} placeholder={placeholder} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500" />
    </div>
  );
}

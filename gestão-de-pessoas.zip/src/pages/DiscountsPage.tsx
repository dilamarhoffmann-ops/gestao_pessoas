import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Plus, Check, FileText, Upload, Download, AlertCircle, X } from 'lucide-react';
import { cn } from '@/lib/utils';

type Discount = {
  id: number;
  employee_name: string;
  type: string;
  value: number;
  installments: number;
  status: 'pending_initial' | 'pending_doc' | 'pending_final' | 'approved';
  created_at: string;
};

export default function DiscountsPage() {
  const [discounts, setDiscounts] = useState<Discount[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchDiscounts();
  }, []);

  const fetchDiscounts = async () => {
    try {
      const res = await fetch('/api/discounts');
      const data = await res.json();
      setDiscounts(data);
    } catch (error) {
      console.error('Failed to fetch discounts', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleStatusUpdate = async (id: number, nextStatus: string) => {
    await fetch(`/api/discounts/${id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: nextStatus }),
    });
    fetchDiscounts();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gestão de Descontos</h2>
          <p className="text-gray-500">Validação, documentação e aprovação de descontos em folha.</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 font-medium transition-colors shadow-sm"
        >
          <Plus size={18} /> Novo Desconto
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard label="Total Pendente" value={discounts.filter(d => d.status !== 'approved').length} color="bg-orange-50 text-orange-700" />
        <StatCard label="Aguardando Doc" value={discounts.filter(d => d.status === 'pending_doc').length} color="bg-blue-50 text-blue-700" />
        <StatCard label="Validação Final" value={discounts.filter(d => d.status === 'pending_final').length} color="bg-purple-50 text-purple-700" />
        <StatCard label="Aprovados (Mês)" value={discounts.filter(d => d.status === 'approved').length} color="bg-green-50 text-green-700" />
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Colaborador</th>
              <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Tipo</th>
              <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Valor</th>
              <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Parcelas</th>
              <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {isLoading ? (
              <tr><td colSpan={6} className="p-8 text-center text-gray-500">Carregando...</td></tr>
            ) : discounts.length === 0 ? (
              <tr><td colSpan={6} className="p-8 text-center text-gray-500">Nenhum desconto registrado.</td></tr>
            ) : (
              discounts.map((discount) => (
                <tr key={discount.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 font-medium text-gray-900">{discount.employee_name}</td>
                  <td className="px-6 py-4 text-gray-600">{discount.type}</td>
                  <td className="px-6 py-4 text-gray-900 font-mono">R$ {discount.value.toFixed(2)}</td>
                  <td className="px-6 py-4 text-gray-600">{discount.installments}x</td>
                  <td className="px-6 py-4">
                    <StatusBadge status={discount.status} />
                  </td>
                  <td className="px-6 py-4">
                    <ActionButtons discount={discount} onUpdate={handleStatusUpdate} />
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <NewDiscountModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onCreated={fetchDiscounts} />
    </div>
  );
}

function StatCard({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className={cn("p-4 rounded-xl border border-transparent", color)}>
      <p className="text-sm font-medium opacity-80">{label}</p>
      <p className="text-2xl font-bold mt-1">{value}</p>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    pending_initial: 'bg-orange-100 text-orange-800',
    pending_doc: 'bg-blue-100 text-blue-800',
    pending_final: 'bg-purple-100 text-purple-800',
    approved: 'bg-green-100 text-green-800',
  };
  
  const labels: Record<string, string> = {
    pending_initial: 'Validação Inicial',
    pending_doc: 'Aguardando Doc',
    pending_final: 'Validação Final',
    approved: 'Aprovado',
  };

  return (
    <span className={cn("px-2.5 py-1 rounded-full text-xs font-medium", styles[status] || 'bg-gray-100 text-gray-800')}>
      {labels[status] || status}
    </span>
  );
}

function ActionButtons({ discount, onUpdate }: { discount: Discount; onUpdate: (id: number, status: string) => void }) {
  if (discount.status === 'approved') return <span className="text-green-600 flex items-center gap-1 text-sm"><Check size={16} /> Concluído</span>;

  if (discount.status === 'pending_initial') {
    return (
      <button 
        onClick={() => onUpdate(discount.id, 'pending_doc')}
        className="flex items-center gap-1 px-3 py-1.5 rounded-md text-sm font-medium transition-colors border border-orange-200 bg-orange-50 text-orange-700 hover:bg-orange-100"
      >
        <Check size={16} /> Validar Início
      </button>
    );
  }

  if (discount.status === 'pending_doc') {
    return (
      <div className="flex items-center gap-2">
        <button 
          onClick={() => alert("Documento baixado (simulação)")}
          className="p-1.5 rounded-md text-gray-500 hover:bg-gray-100 hover:text-gray-700"
          title="Baixar Modelo"
        >
          <Download size={16} />
        </button>
        <button 
          onClick={() => onUpdate(discount.id, 'pending_final')}
          className="flex items-center gap-1 px-3 py-1.5 rounded-md text-sm font-medium transition-colors border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100"
        >
          <Upload size={16} /> Enviar Doc
        </button>
      </div>
    );
  }

  if (discount.status === 'pending_final') {
    return (
      <div className="flex items-center gap-2">
         <button 
          onClick={() => alert("Visualizando documento (simulação)")}
          className="p-1.5 rounded-md text-gray-500 hover:bg-gray-100 hover:text-gray-700"
          title="Ver Documento"
        >
          <FileText size={16} />
        </button>
        <button 
          onClick={() => onUpdate(discount.id, 'approved')}
          className="flex items-center gap-1 px-3 py-1.5 rounded-md text-sm font-medium transition-colors border border-purple-200 bg-purple-50 text-purple-700 hover:bg-purple-100"
        >
          <Check size={16} /> Aprovar Final
        </button>
      </div>
    );
  }

  return null;
}

function NewDiscountModal({ isOpen, onClose, onCreated }: { isOpen: boolean; onClose: () => void; onCreated: () => void }) {
  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    await fetch('/api/discounts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        employee_name: formData.get('employee_name'),
        type: formData.get('type'),
        value: Number(formData.get('value')),
        installments: Number(formData.get('installments')),
      }),
    });
    
    onCreated();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
          <X size={20} />
        </button>
        <h3 className="text-lg font-bold text-gray-900 mb-4">Novo Desconto</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Colaborador</label>
            <input name="employee_name" required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" placeholder="Nome completo" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tipo de Desconto</label>
            <select name="type" className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
              <option value="Adiantamento">Adiantamento Salarial</option>
              <option value="Dano">Dano ao Patrimônio</option>
              <option value="Empréstimo">Empréstimo Consignado</option>
              <option value="Outros">Outros</option>
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Valor (R$)</label>
              <input name="value" type="number" step="0.01" required className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" placeholder="0.00" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Parcelas</label>
              <input name="installments" type="number" min="1" defaultValue="1" className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
            </div>
          </div>
          <div className="flex justify-end gap-3 mt-6">
            <button type="button" onClick={onClose} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancelar</button>
            <button type="submit" className="px-4 py-2 bg-indigo-600 text-white hover:bg-indigo-700 rounded-lg font-medium">Criar Desconto</button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Plus, User, Mail, ArrowRight, CheckCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

type Candidate = {
  id: number;
  name: string;
  position: string;
  email: string;
  status: 'applied' | 'interview1' | 'interview2' | 'offer' | 'hired';
  interview_notes?: string;
};

const COLUMNS = [
  { id: 'applied', label: 'Inscritos', color: 'bg-gray-100 border-gray-200' },
  { id: 'interview1', label: '1ª Entrevista', color: 'bg-blue-50 border-blue-100' },
  { id: 'interview2', label: '2ª Entrevista', color: 'bg-indigo-50 border-indigo-100' },
  { id: 'offer', label: 'Proposta/Doc', color: 'bg-purple-50 border-purple-100' },
  { id: 'hired', label: 'Contratado', color: 'bg-green-50 border-green-100' },
];

export default function HiringPage() {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    fetchCandidates();
  }, []);

  const fetchCandidates = async () => {
    const res = await fetch('/api/candidates');
    const data = await res.json();
    setCandidates(data);
  };

  const moveCandidate = async (id: number, currentStatus: string) => {
    const statusOrder = ['applied', 'interview1', 'interview2', 'offer', 'hired'];
    const currentIndex = statusOrder.indexOf(currentStatus);
    if (currentIndex === -1 || currentIndex === statusOrder.length - 1) return;

    const nextStatus = statusOrder[currentIndex + 1];

    await fetch(`/api/candidates/${id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: nextStatus }),
    });
    fetchCandidates();
  };

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Fluxo de Contratação</h2>
          <p className="text-gray-500">Pipeline de talentos e gestão de admissão.</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 font-medium shadow-sm"
        >
          <Plus size={18} /> Novo Candidato
        </button>
      </div>

      <div className="flex-1 overflow-x-auto">
        <div className="flex gap-4 min-w-max h-full pb-4">
          {COLUMNS.map((col) => (
            <div key={col.id} className={cn("w-80 flex-shrink-0 rounded-xl border p-4 flex flex-col", col.color)}>
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-gray-700">{col.label}</h3>
                <span className="bg-white/50 px-2 py-0.5 rounded text-sm font-medium text-gray-600">
                  {candidates.filter(c => c.status === col.id).length}
                </span>
              </div>
              
              <div className="flex-1 overflow-y-auto space-y-3">
                {candidates
                  .filter(c => c.status === col.id)
                  .map(candidate => (
                    <CandidateCard key={candidate.id} candidate={candidate} onMove={() => moveCandidate(candidate.id, candidate.status)} />
                  ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <NewCandidateModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onCreated={fetchCandidates} />
    </div>
  );
}

function CandidateCard({ candidate, onMove }: { candidate: Candidate; onMove: () => void }) {
  return (
    <motion.div 
      layoutId={`candidate-${candidate.id}`}
      className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 group hover:shadow-md transition-all"
    >
      <div className="flex items-start justify-between">
        <div>
          <h4 className="font-bold text-gray-900">{candidate.name}</h4>
          <p className="text-sm text-indigo-600 font-medium">{candidate.position}</p>
        </div>
      </div>
      
      <div className="mt-3 flex items-center gap-2 text-xs text-gray-500">
        <Mail size={12} />
        <span className="truncate max-w-[180px]">{candidate.email}</span>
      </div>

      {candidate.status !== 'hired' && (
        <button 
          onClick={onMove}
          className="mt-4 w-full flex items-center justify-center gap-1 text-xs font-medium py-1.5 rounded bg-gray-50 text-gray-600 hover:bg-indigo-50 hover:text-indigo-700 transition-colors opacity-0 group-hover:opacity-100"
        >
          Avançar Etapa <ArrowRight size={12} />
        </button>
      )}
    </motion.div>
  );
}

function NewCandidateModal({ isOpen, onClose, onCreated }: { isOpen: boolean; onClose: () => void; onCreated: () => void }) {
  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    await fetch('/api/candidates', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: formData.get('name'),
        position: formData.get('position'),
        email: formData.get('email'),
      }),
    });
    
    onCreated();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Novo Candidato</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Nome Completo</label>
            <input name="name" required className="w-full px-3 py-2 border border-gray-300 rounded-lg" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Cargo / Vaga</label>
            <input name="position" required className="w-full px-3 py-2 border border-gray-300 rounded-lg" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input name="email" type="email" required className="w-full px-3 py-2 border border-gray-300 rounded-lg" />
          </div>
          <div className="flex justify-end gap-3 mt-6">
            <button type="button" onClick={onClose} className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg">Cancelar</button>
            <button type="submit" className="px-4 py-2 bg-indigo-600 text-white hover:bg-indigo-700 rounded-lg font-medium">Adicionar</button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

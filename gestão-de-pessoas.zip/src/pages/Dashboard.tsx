export default function Dashboard() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Dashboard Geral</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl p-6 text-white shadow-lg">
          <h3 className="text-lg font-medium opacity-90">Descontos Pendentes</h3>
          <p className="text-4xl font-bold mt-2">12</p>
          <p className="text-sm opacity-75 mt-4">Aguardando validação</p>
        </div>
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
          <h3 className="text-lg font-medium text-gray-500">Processos Ativos</h3>
          <p className="text-4xl font-bold text-gray-900 mt-2">5</p>
          <div className="flex items-center gap-2 mt-4 text-red-600 text-sm font-medium">
            <span className="w-2 h-2 rounded-full bg-red-600"></span>
            2 com prazo próximo
          </div>
        </div>
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
          <h3 className="text-lg font-medium text-gray-500">Vagas Abertas</h3>
          <p className="text-4xl font-bold text-gray-900 mt-2">8</p>
          <p className="text-sm text-gray-400 mt-4">3 candidatos em entrevista final</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <h3 className="font-bold text-gray-900 mb-4">Atividades Recentes</h3>
          <ul className="space-y-4">
            <li className="flex gap-3 text-sm">
              <div className="w-2 h-2 mt-1.5 rounded-full bg-green-500 flex-shrink-0"></div>
              <span className="text-gray-600"><strong className="text-gray-900">João Silva</strong> foi contratado para Desenvolvedor Senior.</span>
            </li>
            <li className="flex gap-3 text-sm">
              <div className="w-2 h-2 mt-1.5 rounded-full bg-blue-500 flex-shrink-0"></div>
              <span className="text-gray-600">Novo desconto de adiantamento cadastrado para <strong className="text-gray-900">Maria Souza</strong>.</span>
            </li>
            <li className="flex gap-3 text-sm">
              <div className="w-2 h-2 mt-1.5 rounded-full bg-red-500 flex-shrink-0"></div>
              <span className="text-gray-600">Prazo processual do caso <strong className="text-gray-900">00234-2024</strong> vence em 3 dias.</span>
            </li>
          </ul>
        </div>
        
        <div className="bg-slate-900 p-6 rounded-xl text-white shadow-lg">
          <h3 className="font-bold mb-4">Acesso Rápido</h3>
          <div className="grid grid-cols-2 gap-4">
            <button className="bg-slate-800 hover:bg-slate-700 p-4 rounded-lg text-left transition-colors">
              <span className="block text-indigo-400 mb-1">Nova Admissão</span>
              <span className="text-sm text-slate-400">Iniciar processo</span>
            </button>
            <button className="bg-slate-800 hover:bg-slate-700 p-4 rounded-lg text-left transition-colors">
              <span className="block text-green-400 mb-1">Relatórios</span>
              <span className="text-sm text-slate-400">Baixar mensal</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
